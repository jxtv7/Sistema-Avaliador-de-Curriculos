def classify_skills(skills):
    """
    REGRA DE NEGÓCIO ESTRITA: 
    Só aceita palavras que constam no dicionário de Ferramentas, Habilidades ou Conhecimentos.
    """
    
    # 1. FERRAMENTAS: Softwares, linguagens, plataformas
    ferramentas_keywords = {
        # OFFICE / PRODUTIVIDADE
        "excel", "word", "powerpoint", "outlook", "access",
        "google sheets", "google docs", "google drive",

        # BI / DADOS
        "power bi", "tableau", "qlik", "qlikview", "metabase",
        "looker", "data studio", "sql", "mysql", "postgresql",
        "mongodb", "oracle", "bigquery", "snowflake",

        # PROGRAMAÇÃO
        "python", "java", "javascript", "typescript", "c#", "c++",
        "php", "node", "react", "angular", "vue", "spring boot",

        # CLOUD / DEVOPS
        "aws", "azure", "gcp", "docker", "kubernetes",
        "terraform", "jenkins", "git", "github", "gitlab",

        # ERP / CORPORATIVO
        "sap", "totvs", "protheus", "salesforce", "hubspot",
        "oracle erp", "dynamics", "crm", "erp",

        # DESIGN
        "figma", "photoshop", "illustrator", "canva", "autocad",

        # MARKETING
        "google analytics", "meta ads", "google ads",
        "rd station", "mailchimp",

        # RH
        "gupy", "kenoby", "linkedin recruiter",

        # FINANCEIRO
        "sap fi", "omie", "alterdata", "sienge",

        # LOGÍSTICA
        "wms", "tms", "sap mm",

        # ENGENHARIA
        "revit", "solidworks", "catia",

        # SAÚDE
        "tasy", "mv", "pep",

        # GESTÃO
        "jira", "trello", "asana", "notion", "clickup"
    }

    # 2. HABILIDADES: Ações, Soft Skills e competências comportamentais
    habilidades_keywords = {

        # COMPORTAMENTAIS
        "liderança", "comunicação", "negociação", "proatividade",
        "organização", "resiliência", "empatia", "criatividade",
        "colaboração", "trabalho em equipe", "adaptabilidade",
        "flexibilidade", "comprometimento", "ética",

        # ANALÍTICAS
        "análise", "analisar", "raciocínio lógico",
        "resolução de problemas", "tomada de decisão",
        "pensamento crítico",

        # GESTÃO
        "gestão", "gerenciamento", "planejamento",
        "coordenação", "supervisão", "estratégia",
        "gestão de equipe", "gestão de projetos",

        # COMERCIAL
        "vendas", "atendimento", "relacionamento com cliente",
        "prospecção", "fidelização",

        # OPERACIONAL
        "controle", "monitoramento", "execução",
        "organização de processos",

        # RH
        "recrutamento", "seleção", "treinamento",
        "desenvolvimento de pessoas",

        # FINANCEIRO
        "controle financeiro", "análise financeira",
        "fluxo de caixa", "conciliação",

        # LOGÍSTICA
        "controle de estoque", "roteirização",
        "gestão logística",

        # MARKETING
        "copywriting", "produção de conteúdo",
        "branding", "gestão de campanhas",

        # TI
        "desenvolvimento", "programação",
        "debugging", "suporte técnico",
        "automação", "documentação"
    }

    # 3. CONHECIMENTOS: Metodologias, conceitos e frameworks
    conhecimentos_keywords = {

        # METODOLOGIAS
        "scrum", "kanban", "agile", "lean",
        "six sigma", "pmbok",

        # NEGÓCIO
        "kpi", "okr", "roi", "forecast",
        "budget", "indicadores",

        # FINANCEIRO
        "contabilidade", "finanças",
        "planejamento financeiro",
        "auditoria", "custos",

        # RH
        "departamento pessoal",
        "legislação trabalhista",
        "folha de pagamento",

        # LOGÍSTICA
        "cadeia de suprimentos",
        "supply chain",
        "armazenagem",

        # MARKETING
        "seo", "tráfego pago",
        "funil de vendas",
        "inbound marketing",

        # DADOS
        "estatística", "machine learning",
        "data science", "etl",
        "data warehouse",

        # TI
        "api", "rest", "microserviços",
        "arquitetura", "devops",
        "segurança da informação",
        "lgpd",

        # JURÍDICO
        "compliance", "direito civil",
        "direito trabalhista",

        # ENGENHARIA
        "gestão de obras",
        "desenho técnico",

        # SAÚDE
        "atendimento clínico",
        "biossegurança",

        # ADMINISTRATIVO
        "processos administrativos",
        "gestão empresarial"
    }

    categorias = {
        "habilidades": [],
        "ferramentas": [],
        "conhecimentos": []
    }

    # Criamos um conjunto mestre para busca rápida (Whitelist)
    whitelist_master = ferramentas_keywords | habilidades_keywords | conhecimentos_keywords

    for skill in skills:
        skill_clean = skill.strip().lower()

        # SÓ SEGUE SE A PALAVRA ESTIVER NA WHITELIST
        if skill_clean in whitelist_master:
            if skill_clean in ferramentas_keywords:
                categorias["ferramentas"].append(skill_clean)
            elif skill_clean in habilidades_keywords:
                categorias["habilidades"].append(skill_clean)
            elif skill_clean in conhecimentos_keywords:
                categorias["conhecimentos"].append(skill_clean)

    return categorias