from utils.text_utils import extract_keywords_dynamic

def extract_skills_dynamic(tokens):
    """ Heurística simples para identificar possíveis skills """
    skills = []
    for word in tokens:
        if len(word) >= 3:
            skills.append(word)
    return list(set(skills))

def extract_experience_indicators(text):
    """ Detecta sinais de experiência no currículo """
    indicators = []
    if "%" in text: indicators.append("percentual")
    if "anos" in text: indicators.append("tempo_experiencia")
    if "projeto" in text: indicators.append("projetos")
    if "experiência" in text or "experiencia" in text: indicators.append("experiencia_formal")
    return indicators

def parse_resume(text):
    """ Função principal de parsing do currículo """
    
    # 1. Puxa os dados estruturados do Utils
    extracted_data = extract_keywords_dynamic(text)
    tokens = extracted_data["keywords"]
    skills_catalogo = extracted_data["skills"]

    # 2. Extrai skills dinâmicas baseadas nos tokens
    skills_dinamicas = extract_skills_dynamic(tokens)

    # 3. Junta as skills do catálogo com as dinâmicas (removendo duplicatas)
    todas_skills = list(set(skills_catalogo + skills_dinamicas))

    # 4. Indicadores de experiência
    indicators = extract_experience_indicators(text.lower())

    return {
        "skills": todas_skills,
        "keywords": tokens,
        "indicators": indicators,
        "raw_text": text.lower()
    }