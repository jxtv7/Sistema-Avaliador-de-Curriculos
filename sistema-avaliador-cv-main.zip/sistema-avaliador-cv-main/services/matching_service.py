def normalize_list(words):
    return [w.strip().lower() for w in words]



def calculate_match(parsed_resume, parsed_job):
    """
    REGRA: Score por Aderência de Requisitos.
    O score é calculado exclusivamente sobre o que a vaga exige.
    """
    # Normalização para comparação precisa
    resume_skills = set(s.lower().strip() for s in parsed_resume.get("skills", []))
    job_skills = set(s.lower().strip() for s in parsed_job.get("required_skills", []))

    if not job_skills:
        return {"score": 0, "matched": [], "missing": []}

    # Interseção e Diferença
    matched = list(resume_skills & job_skills)
    missing = list(job_skills - resume_skills)

    # Cálculo de Cobertura
    # Se a vaga pede 5 coisas e você tem 5, é 100%. Se a vaga muda para 10 coisas, sua nota cai para 50%.
    raw_score = (len(matched) / len(job_skills)) * 100

    # Penalidade por Falta de Requisitos Críticos (Opcional)
    # Se o candidato tem menos de 20% da vaga, o score é penalizado para indicar baixa fit.
    final_match_score = raw_score if raw_score > 20 else raw_score * 0.5

    return {
        "score": round(final_match_score, 2),
        "matched": matched,
        "missing": missing,
        "total_required": len(job_skills),
        "total_matched": len(matched)
    }