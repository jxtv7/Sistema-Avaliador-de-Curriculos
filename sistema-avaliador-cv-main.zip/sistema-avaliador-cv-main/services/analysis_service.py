# analysis_service.py -> Orquestra os serviços | Maestro da orquestra

from services.resume_parser_service import parse_resume
from services.job_parser_service import parse_job
from services.resume_analyzer_service import analyze_resume
from services.matching_service import calculate_match
from services.scoring_service import calculate_final_score
from services.classification_service import classify_skills
from services.feedback_service import generate_feedback

def analyze_all(resume_text, job_text):
    """
    REGRA DE NEGÓCIO: Ponderação Dinâmica e Filtragem por Whitelist.
    O score final reflete 70% de aderência técnica (Vaga) 
    e 30% de qualidade estrutural (Currículo).
    """
    try:
        # 1. Parsers (Extração de dados brutos do texto)
        parsed_resume = parse_resume(resume_text)
        parsed_job = parse_job(job_text)

        # 2. Análise Estrutural do Currículo (Qualidade do documento)
        analysis = analyze_resume(parsed_resume)

        # 3. CLASSIFICAÇÃO E FILTRAGEM (A mágica acontece aqui)
        # Passamos as skills brutas pelo dicionário (Whitelist) para remover ruídos
        class_res = classify_skills(parsed_resume.get("skills", []))
        class_job = classify_skills(parsed_job.get("required_skills", []))

        # Criamos listas "limpas" (apenas o que o dicionário aprovou)
        resume_skills_limpas = class_res["ferramentas"] + class_res["habilidades"] + class_res["conhecimentos"]
        job_skills_limpas = class_job["ferramentas"] + class_job["habilidades"] + class_job["conhecimentos"]

        # 4. MATCHING ANALÍTICO (Agora usando apenas as palavras aprovadas)
        # Substituímos os dados brutos pelos dados filtrados pela Whitelist
        match = calculate_match(
            {"skills": resume_skills_limpas}, 
            {"required_skills": job_skills_limpas}
        )

        # 5. Cálculo do Score Final Ponderado
        # resume_base_score: Média das categorias de qualidade (Skills, Impacto, etc)
        resume_base_score = sum([v["score"] for v in analysis.values()]) / len(analysis)
        
        # O final_score agora é justo, pois 'match' não contém mais palavras 'lixo'
        final_score = round((resume_base_score * 0.3) + (match["score"] * 0.7), 2)

        # 6. Estatísticas para a Tabela (Métricas de Volume)
        comparison_stats = {
            "Habilidades": {"cand": len(class_res["habilidades"]), "vaga": len(class_job["habilidades"])},
            "Ferramentas": {"cand": len(class_res["ferramentas"]), "vaga": len(class_job["ferramentas"])},
            "Conhecimentos": {"cand": len(class_res["conhecimentos"]), "vaga": len(class_job["conhecimentos"])}
        }

        # 7. Geração de Feedback Narrativo
        # O feedback usará 'matched' e 'missing' já filtrados pela Whitelist
        feedback_text = generate_feedback(resume_base_score, match["score"], match["matched"], match["missing"])

        return {
            "resume": {
                "score": round(resume_base_score, 2),
                "categories": analysis
            },
            "match": match,
            "comparison_stats": comparison_stats,
            "final_compatibility": final_score,
            "feedback": feedback_text
        }
    except Exception as e:
        print(f"ERRO CRÍTICO NO ANALYSIS_SERVICE: {e}")
        return None