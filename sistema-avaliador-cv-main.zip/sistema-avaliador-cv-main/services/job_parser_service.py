from utils.text_utils import extract_keywords_dynamic

def extract_required_skills(tokens):
    """ Extrai skills da vaga com heurística semelhante ao currículo """
    GENERIC_WORDS = {
        "procuramos", "experiencia", "responsavel", "empresa",
        "vaga", "atividade", "atuacao", "area", "conhecimento"
    }
    skills = []
    for word in tokens:
        if word in GENERIC_WORDS or len(word) < 3:
            continue
        skills.append(word)
    return list(set(skills))

def extract_job_requirements(text):
    """ Identifica indicadores de exigência da vaga """
    text = text.lower()
    requirements = []
    if "obrigatorio" in text: requirements.append("obrigatorio")
    if "desejavel" in text: requirements.append("desejavel")
    if "diferencial" in text: requirements.append("diferencial")
    if "anos" in text: requirements.append("tempo_experiencia")
    return requirements

def parse_job(text):
    """ Função principal de parsing da vaga """
    
    # 1. Puxa os dados estruturados do Utils
    extracted_data = extract_keywords_dynamic(text)
    tokens = extracted_data["keywords"]
    skills_catalogo = extracted_data["skills"]

    # 2. Extrai requirements (dinâmicos) da vaga
    skills_dinamicas = extract_required_skills(tokens)

    # 3. Junta as skills mapeadas pelo catálogo com as dinâmicas
    todas_skills = list(set(skills_catalogo + skills_dinamicas))

    requirements = extract_job_requirements(text)

    return {
        "required_skills": todas_skills,
        "keywords": tokens,
        "requirements": requirements,
        "raw_text": text.lower()
    }