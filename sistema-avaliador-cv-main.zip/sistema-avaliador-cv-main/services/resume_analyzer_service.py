# resume_analyzer_service.py

def analyze_impact(parsed_resume):
    """Mede a densidade de resultados (números, métricas, verbos de ação)."""
    text = parsed_resume.get("raw_text", "").lower()
    score = 40  # Base
    
    indicadores = ["%", "r$", "usd", "clientes", "projetos", "reduzi", "aumentei", "liderança", "gerenciei"]
    for ind in indicadores:
        if ind in text:
            score += 10
    return min(score, 100)

def analyze_ats(parsed_resume):
    """Verifica se a densidade de palavras-chave é saudável para robôs."""
    num_keywords = len(parsed_resume.get("skills", []))
    if 10 <= num_keywords <= 25:
        return 95
    elif num_keywords > 25:
        return 70  # Penaliza excesso (Keyword Stuffing)
    return 50

def analyze_resume(parsed_resume):
    """
    Retorna o dicionário completo de categorias com regras de negócio aprimoradas.
    """
    return {
        "skills": {
            "score": min(len(parsed_resume.get("skills", [])) * 6, 100),
            "desc": "Quantidade de competências detectadas."
        },
        "impact": {
            "score": analyze_impact(parsed_resume),
            "desc": "Presença de métricas e resultados quantificáveis."
        },
        "structure": {
            "score": 85 if len(parsed_resume.get("raw_text", "")) > 500 else 60,
            "desc": "Organização e volume de informações profissionais."
        },
        "ats": {
            "score": analyze_ats(parsed_resume),
            "desc": "Otimização para leitura por sistemas automáticos."
        },
        "narrative": {
            "score": 75 if "experiência" in parsed_resume.get("raw_text", "").lower() else 40,
            "desc": "Coerência na descrição da trajetória."
        }
    }