def generate_feedback(resume_score, match_score, matched, missing):

    feedback = []

    # 🔹 Avaliação geral
    if resume_score >= 80:
        feedback.append("Seu currículo apresenta uma estrutura sólida e bem desenvolvida.")
    elif resume_score >= 60:
        feedback.append("Seu currículo é bom, mas ainda possui pontos de melhoria.")
    else:
        feedback.append("Seu currículo precisa de melhorias estruturais e de conteúdo.")

    # 🔹 Match com a vaga
    if match_score >= 80:
        feedback.append("Seu perfil possui alta aderência à vaga.")
    elif match_score >= 60:
        feedback.append("Seu perfil possui aderência moderada à vaga.")
    else:
        feedback.append("Seu perfil possui baixa aderência à vaga.")

    # 🔹 Pontos fortes
    if matched:
        top_skills = ", ".join(matched[:5])
        feedback.append(f"Seus principais pontos fortes incluem: {top_skills}.")

    # 🔹 Gaps
    if missing:
        gaps = ", ".join(missing[:5])
        feedback.append(f"Para aumentar suas chances, recomenda-se desenvolver ou destacar: {gaps}.")
    else:
        feedback.append("Você atende a todos os principais requisitos da vaga.")

    return " ".join(feedback)