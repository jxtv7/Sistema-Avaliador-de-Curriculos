 # scoring_service.py -> Responsável por calcular o score em um score final

def calculate_final_score(scores_dict):
    """
    Calcula o score final do currículo

    Recebe um dicionário com notas por categoria
    e retorna a média
    """

    # Garantia de segurança (evita erro se vier vazio)
    if not scores_dict:
        return 0
    
    # Soma das notas
    total = sum(scores_dict.values())

    # Quantidade de categorias
    count = len(scores_dict)

    # Média final
    final_score = total / count

    return round(final_score, 2) # arredonda para 2 casas decimais 
