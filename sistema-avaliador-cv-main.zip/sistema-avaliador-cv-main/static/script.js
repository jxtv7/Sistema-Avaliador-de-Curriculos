function analisar() {

  document.getElementById("erro").style.display = "none";

  const curriculo = document.getElementById("curriculo").value.trim();
  const vaga = document.getElementById("vaga").value.trim();

  // 1. Campos vazios
  if (!curriculo || !vaga) {
    mostrarErro("Preencha os dois campos!");
    return;
  }

  // 2. Texto muito curto
  if (curriculo.length < 20) {
    mostrarErro("O currículo parece muito curto!");
    return;
  }

  if (vaga.length < 20) {
    mostrarErro("A descrição da vaga parece muito curta!");
    return;
  }

  // 3. Validação simples por palavras-chave
  const palavrasCurriculo = [

    // EXPERIÊNCIA
    "experiência", "atuação", "trajetória", "profissional",
    "empresa", "empresas", "cargo", "função",
    "responsável", "responsabilidades",

    // FORMAÇÃO
    "graduação", "faculdade", "universidade",
    "curso", "certificação", "formação",
    "ensino", "mba", "pós-graduação",

    // HABILIDADES
    "habilidades", "competências", "conhecimentos",
    "tecnologias", "ferramentas", "skills",

    // ÁREAS CORPORATIVAS
    "financeiro", "administrativo", "comercial",
    "marketing", "logística", "rh", "contabilidade",
    "engenharia", "dados", "tecnologia",

    // AÇÕES PROFISSIONAIS
    "análise", "gestão", "controle", "planejamento",
    "desenvolvimento", "implementação", "suporte",
    "liderança", "coordenação", "monitoramento",

    // FERRAMENTAS
    "excel", "power bi", "sap", "totvs",
    "sql", "python", "crm", "erp",

    // RESULTADOS
    "indicadores", "resultados", "performance",
    "metas", "relatórios", "dashboard",

    // IDIOMAS
    "idiomas", "inglês", "espanhol"
  ];

  const palavrasVaga = [

    // REQUISITOS
    "requisitos", "qualificações", "necessário",
    "desejável", "obrigatório", "perfil",

    // DESCRIÇÃO
    "responsabilidades", "atividades",
    "atribuições", "desafios", "rotina",

    // CONTRATAÇÃO
    "vaga", "oportunidade", "contratação",
    "clt", "pj", "home office",
    "remoto", "híbrido", "presencial",

    // EMPRESA
    "empresa", "time", "equipe",
    "procuramos", "buscamos",

    // ÁREAS
    "financeiro", "administrativo", "marketing",
    "comercial", "logística", "rh",
    "engenharia", "dados", "tecnologia",

    // HABILIDADES
    "experiência", "conhecimento",
    "habilidade", "competência",

    // FERRAMENTAS
    "excel", "power bi", "sap", "totvs",
    "sql", "python", "crm", "erp",

    // ENTREGAS
    "indicadores", "relatórios",
    "dashboard", "planejamento",
    "análise", "gestão"
  ];

  function contarOcorrencias(texto, palavras) {
    let contador = 0;

    palavras.forEach(palavra => {
      if (texto.includes(palavra)) {
        contador++;
      }
    });

    return contador;
  }
  const textoCurriculo = curriculo.toLowerCase();
  const textoVaga = vaga.toLowerCase();

  const scoreCurriculo = contarOcorrencias(textoCurriculo, palavrasCurriculo);
  const scoreVaga = contarOcorrencias(textoVaga, palavrasVaga);

  // mínimo de aderência textual
  if (scoreCurriculo < 3) {
    alert("O texto do currículo parece inválido ou pouco detalhado.");
    return;
  }

  if (scoreVaga < 3) {
    alert("A descrição da vaga parece inválida ou incompleta.");
    return;
  }
  
  // Mostrar loading
  const loading = document.getElementById("loading");
  loading.style.display = "block";

  // força o navegador a renderizar o loading
  loading.offsetHeight;

  // pequeno delay real para garantir visualização
  setTimeout(() => {

    fetch("http://127.0.0.1:5000/analyze", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        resume_text: curriculo,
        job_text: vaga
      })
    })
    .then(response => {
      if (!response.ok) {
        throw new Error("Erro na resposta do servidor");
      }
      return response.json();
    })
    .then(data => {

      localStorage.setItem("resultado", JSON.stringify(data));

      window.location.href = "/resultado";
    })
    .catch(error => {
      console.error("Erro:", error);

      document.getElementById("loading").style.display = "none";

      mostrarErro("Erro ao conectar com o servidor. Verifique se o backend está rodando.");
    });

  }, 1700); // delay um pouco maior para garantir visibilidade
}


// Função para mostrar erro na tela
function mostrarErro(mensagem) {
  const erro = document.getElementById("erro");

  erro.innerText = mensagem;
  erro.style.display = "block";
}