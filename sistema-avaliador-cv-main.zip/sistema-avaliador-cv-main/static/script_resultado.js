const dados = JSON.parse(localStorage.getItem("resultado")) || {};

// Traduções para exibição nos cards
const traducoes = {
    "skills": "Habilidades Técnicas",
    "impact": "Impacto",
    "structure": "Estrutura",
    "ats": "Otimização ATS",
    "narrative": "Narrativa"
};

const blacklist = ["categories", "keywords", "skills", "required_skills", "raw_text", "vaga", "curriculo"];

const filtrarSkills = (lista) => {
    if (!lista) return [];
    return lista.filter(s => !blacklist.includes(s.toLowerCase()) && s.length > 2);
};

// --- RENDERIZAÇÃO ---

// 🔹 Scores principais (Removido o "?" e tooltips)
const scoreCurriculoCont = document.getElementById("scoreCurriculo");
if (scoreCurriculoCont) {
    scoreCurriculoCont.innerText = `${dados.resume?.score || 0}/100`;
}

const scoreVagaCont = document.getElementById("scoreVaga");
if (scoreVagaCont) {
    scoreVagaCont.innerText = `${dados.match?.score || 0}%`;
}

// 🔹 Cards de Análise Detalhada (Barras corrigidas e "?" removido)
const analiseGrid = document.getElementById("analise-grid-container");
if (analiseGrid) {
    analiseGrid.innerHTML = "";
    const categorias = dados.resume?.categories || {};
    
    Object.entries(categorias).forEach(([nome, info]) => {
        const nomeTraduzido = traducoes[nome] || nome;
        const valorScore = info.score || 0; // Garante que é um número
        
        const card = `
            <div class="card" style="margin-bottom: 15px;">
                <div style="display: flex; justify-content: space-between; align-items: center; width: 100%;">
                    <p style="margin: 0;">${nomeTraduzido}</p>
                    <strong>${valorScore}</strong>
                </div>
                <div style="width: 100%; background: #eee; height: 8px; border-radius: 10px; margin-top: 8px; overflow: hidden;">
                    <div style="width: ${valorScore}%; background: #2ecc71; height: 100%; border-radius: 10px; transition: width 0.4s ease-out;">
                    </div>
                </div>
            </div>
        `;
        analiseGrid.innerHTML += card;
    });
}

// 🔹 Tabela Comparativa (Candidato vs Vaga)
const stats = dados.comparison_stats || {};
const tabelaCorpo = document.getElementById("comparacao-vaga-tabela");
if (tabelaCorpo) {
    tabelaCorpo.innerHTML = Object.entries(stats).map(([chave, val]) => `
        <tr>
            <td style="text-transform: capitalize;">${chave}</td>
            <td>${val.cand}</td>
            <td>${val.vaga}</td>
        </tr>
    `).join('');
}

// 🔹 Checklist de Competências
const matchedOriginal = dados.match?.matched || [];
const missingOriginal = dados.match?.missing || [];
const matchedClean = filtrarSkills(matchedOriginal);
const missingClean = filtrarSkills(missingOriginal);
const todasSkills = [...matchedClean, ...missingClean].slice(0, 10);

const listaSkillsMatch = document.getElementById("lista-skills-match");
if (listaSkillsMatch) {
    listaSkillsMatch.innerHTML = todasSkills.map(skill => {
        const check = matchedClean.includes(skill) ? "✅" : "❌";
        return `<li>${check} ${skill}</li>`;
    }).join('');
}

// 🔹 Gaps e Recomendações
const gapsLista = document.getElementById("gaps-lista");
if (gapsLista) {
    if (missingClean.length === 0) {
        gapsLista.innerHTML = "<li>✅ Perfil altamente compatível! Nenhum gap crítico identificado.</li>";
    } else {
        gapsLista.innerHTML = missingClean.slice(0, 5).map(skill => 
            `<li>⚠️ Recomenda-se destacar ou desenvolver: <strong>${skill}</strong></li>`
        ).join('');
    }
}

// 🔹 Feedback Geral
const feedbackText = document.getElementById("feedback-text");
if (feedbackText) {
    feedbackText.innerText = dados.feedback || "Análise processada. Verifique os pontos de atenção abaixo.";
}