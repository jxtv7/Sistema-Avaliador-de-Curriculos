

SKILLS_LIST = [
    "python",
    "sql",
    "aws",
    "power bi",
    "spark",
    "databricks",
    "etl",
    "excel",
    "azure"
] 