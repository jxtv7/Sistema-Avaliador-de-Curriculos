import re

def extract_keywords_dynamic(text):
    """
    Extrai palavras relevantes com filtro inteligente (nível ATS)
    """

    text = text.lower()

    # 🔹 Remove pontuação
    # No arquivo text_utils.py
    text = re.sub(r"[^\w\s#\+]", "", text)

    tokens = text.split()

    # 🔹 Stopwords ampliado (palavras inúteis)
    STOPWORDS = {
        "de", "da", "do", "das", "dos", "e", "em", "para",
        "com", "um", "uma", "o", "a", "os", "as", "no", "na",
        "tenho", "procuramos", "experiencia", "experiência",
        "conhecimento", "conhecimentos", "atuacao", "atuação",
        "responsavel", "responsável", "realizo", "realizar",
        "atuar", "trabalhar", "trabalho", "empresa", "area",
        "cargo", "atividade", "atividades"
    }

    # 🔹 Verbos comuns (lixo para análise de skills)
    VERBOS = {
        "fazer", "criar", "desenvolver", "analisar", "montar",
        "usar", "utilizar", "executar", "implementar",
        "gerar", "apoiar", "auxiliar", "participar",
        "liderar", "acompanhar"
    }

    # 🔹 Lista de skills conhecidas
    SKILLS_CATALOG = {

        # 💻 TECNOLOGIA / DADOS
        "tech_data": {
            "python", "sql", "spark", "hadoop", "databricks",
            "etl", "elt", "pipeline", "airflow", "dbt",
            "pandas", "numpy", "powerbi", "tableau",
            "looker", "excel", "vba"
        },

        # ☁️ CLOUD / DEVOPS
        "cloud_devops": {
            "aws", "azure", "gcp", "docker", "kubernetes",
            "terraform", "ci", "cd", "jenkins", "linux"
        },

        # 💼 ADMINISTRATIVO / FINANCEIRO
        "finance_admin": {
            "contabilidade", "fluxo de caixa", "dre",
            "orcamento", "budget", "forecast",
            "planejamento financeiro", "analise financeira",
            "custos", "receita", "despesas", "lucro",
            "faturamento"
        },

        # 📊 NEGÓCIOS / ESTRATÉGIA
        "business": {
            "analise de dados", "kpi", "indicadores",
            "estrategia", "planejamento", "gestao",
            "processos", "melhoria continua",
            "tomada de decisao"
        },

        # 📢 MARKETING
        "marketing": {
            "seo", "sem", "google ads", "facebook ads",
            "copywriting", "branding", "midia paga",
            "analytics", "trafego pago", "conteudo"
        },

        # 🧑‍💼 RH
        "rh": {
            "recrutamento", "selecao", "treinamento",
            "onboarding", "avaliacao de desempenho",
            "gestao de pessoas", "folha de pagamento"
        },

        # 📞 COMERCIAL / VENDAS
        "sales": {
            "vendas", "negociacao", "prospeccao",
            "crm", "funil de vendas", "fechamento",
            "relacionamento com cliente"
        },

        # ⚙️ ENGENHARIA / PRODUÇÃO
        "engineering": {
            "lean", "six sigma", "kanban", "scrum",
            "gestao de projetos", "qualidade",
            "processos industriais"
        },

        # 🧠 SOFT SKILLS
        "soft_skills": {
            "comunicacao", "lideranca", "trabalho em equipe",
            "proatividade", "resolucao de problemas",
            "pensamento analitico", "adaptabilidade"
        }
    }

    # 🔹 Remove stopwords e verbos
    tokens = [
        word for word in tokens
        if word not in STOPWORDS
        and word not in VERBOS
        and len(word) > 2  # evita lixo tipo "de", "em"
    ]

    skills_detectadas = []
    categorias_detectadas = {}

    # 🔥 varre TODAS as categorias
    for categoria, skills in SKILLS_CATALOG.items():

        encontrados = [skill for skill in skills if skill in text]

        if encontrados:
            categorias_detectadas[categoria] = encontrados
            skills_detectadas.extend(encontrados)

    # remove duplicados
    skills_detectadas = list(set(skills_detectadas))

    return {
        "skills": skills_detectadas,
        "categories": categorias_detectadas,
        "keywords": tokens
    }
