from flask import Flask, render_template
from flask_cors import CORS

# 🔹 Importa as rotas
from routes.analysis_routes import analysis_bp

app = Flask(__name__, template_folder="Templates")
CORS(app)

# 🔹 Registra blueprint
app.register_blueprint(analysis_bp)

# 🔹 Rota principal
@app.route("/")
def home():
    return render_template("index.html")

@app.route("/resultado")
def resultado():
    return render_template("resultado.html")

# 🔹 Rodar servidor
if __name__ == "__main__":
    app.run(debug=True)