# analysis_routes.py -> Recebe as requisições do frontend, processa os dados e chama o motor de análise

from flask import Blueprint, request, jsonify

# Importando o serviço principal (ainda vamos criar depois)
from services.analysis_service import analyze_all

# Criando o blueprint
analysis_bp = Blueprint("analysis", __name__) # Cria um grupo de rotas


@analysis_bp.route("/analyze", methods=["POST"]) # define o endpoint | POST -> envia dados para o servidor

def analyze():
    """
    Endpoint principal da aplicação.
    
    Recebe:
        - resume_text
        - job_text

    Retorna:
        - análise completa do currículo + match com a vaga
    """

    # Pegando os dados enviados no corpo da requisição
    data = request.get_json()

    # Extraindo os textos dos campos
    resume_text = data.get("resume_text", "")
    job_text = data.get("job_text", "")

    # Validação simples dos campos para garantir que não estão vazios
    if not resume_text or not job_text:
        return jsonify({
            "error": "Os campos 'resume_text' e 'job_text' são obrigatórios e não podem estar vazios."
        }), 400
    
    # Chamando o serviço principal (por enquanto pode estar mockado)
    result = analyze_all(resume_text, job_text)

    # Retornando resposta
    return jsonify(result), 200